package website;

import java.sql.*;
import java.util.ArrayList;

public class NoticeInfo {
	Connection conn = null;
	PreparedStatement pstmt = null;

	/* MySQL 연결정보 */
	String jdbc_driver = "com.mysql.jdbc.Driver";
	String jdbc_url = "jdbc:mysql://localhost/jspdb?characterEncoding=UTF-8&serverTimezone=UTC";

	// DB연결 메서드
	void connect() {
		try {
			Class.forName(jdbc_driver);

			conn = DriverManager.getConnection(jdbc_url, "jspbook", "1234");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	void disconnect() {
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// 수정된 내용 갱신을 위한 메서드
	public boolean updateDB(int notice_id, String notice_title, String notice_article, String notice_date) {
		connect();

		String sql = "update notice_info set notice_title=?,notice_article=?,notice_date=? where notice_id=?";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, notice_title);
			pstmt.setString(2, notice_article);
			pstmt.setString(3, notice_date);
			pstmt.setInt(4, notice_id);
	
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	// 특정 주소록 게시글 삭제 메서드
	public boolean deleteDB(int notice_id) {
		connect();

		String sql = "delete from notice_info where notice_id=?";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, notice_id);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	// 신규  메시지 추가 메서드
	public boolean insertDB(NoticeBean noticebean) {
		connect();
		// sql 문자열 , gb_id 는 자동 등록 되므로 입력하지 않는다.

		String sql = "insert into notice_info(notice_title,nick,notice_article,notice_date,notice_count) values(?,?,?,?,?)";

		try {
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, noticebean.getNotice_Title());
			pstmt.setString(2 ,noticebean.getNotice_Nick());
			pstmt.setString(3, noticebean.getNotice_Article());
			pstmt.setString(4, noticebean.getNotice_Date());
			pstmt.setInt(5, noticebean.getNotice_Count());
		
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	// 특정 게시글 가져오는 메서드
	//title을 클릭하면 board_id가 선택되어야함
	public NoticeBean getDB(int notice_id, boolean add) {
		connect();

		String sql = "select * from notice_info where notice_id=?";
		NoticeBean noticebean = new NoticeBean();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, notice_id);
			ResultSet rs = pstmt.executeQuery();

			// 데이터가 하나만 있으므로 rs.next()를 한번만 실행 한다.
			rs.next();

			noticebean.setNotice_id(rs.getInt("notice_id"));
			noticebean.setNotice_Title(rs.getString("notice_title"));
			noticebean.setNotice_Nick(rs.getString("nick"));
			noticebean.setNotice_Article(rs.getString("notice_article"));
			noticebean.setNotice_Date(rs.getString("notice_date"));
			noticebean.setNotice_Count(rs.getInt("notice_count"));
			
			//boolean값 add를 받고 모드가 null이면 조회수(count)를 올린다
			if(add) {
				sql = "update notice_info set notice_count=? where notice_id=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(2, notice_id);
				pstmt.setInt(1,noticebean.getNotice_Count()+1);
				pstmt.executeUpdate();				
			}
			
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return noticebean;
	}


	// 전체 주소록 목록을 가져오는 메서드
	public ArrayList<NoticeBean> getDBList() {
		connect();
		ArrayList<NoticeBean> datas = new ArrayList<NoticeBean>();

		String sql = "select * from notice_info order by notice_id desc";
		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				NoticeBean noticebean = new NoticeBean();
				noticebean.setNotice_id(rs.getInt("notice_id"));
				noticebean.setNotice_Title(rs.getString("notice_title"));
				noticebean.setNotice_Nick(rs.getString("nick"));
				noticebean.setNotice_Article(rs.getString("notice_article"));
				noticebean.setNotice_Date(rs.getString("notice_date"));
				noticebean.setNotice_Count(rs.getInt("notice_count"));
				
				datas.add(noticebean);
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return datas;
	}
	
	
}
