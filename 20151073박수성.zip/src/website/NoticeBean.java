package website;

public class NoticeBean {

	private int notice_id;
	private String notice_title;
	private String id;
	private String notice_article;
	private String notice_date;
	private String mode;
	private String nick;
	private int notice_count;
	
	
	public int getNotice_Count() {
		return notice_count;
	}
	public void setNotice_Count(int count) {
		this.notice_count = count;
	}
	public String getNotice_Nick() {
		return nick;
	}
	public void setNotice_Nick(String nick) {
		this.nick = nick;
	}
	public String getNotice_Mode() {
		return mode;
	}
	public void setNotice_Mode(String mode) {
		this.mode = mode;
	}
	public void setNotice_id(int board_id) {
		this.notice_id = board_id;
	}
	public int getNotice_id() {
		return notice_id;
	}
	public String getNotice_Title() {
		return notice_title;
	}
	public void setNotice_Title(String title) {
		this.notice_title = title;
	}
	public String getNotice_Id() {
		return id;
	}
	public void setNotice_Id(String id) {
		this.id = id;
	}
	public String getNotice_Article() {
		return notice_article;
	}
	public void setNotice_Article(String article) {
		this.notice_article = article;
	}
	public String getNotice_Date() {
		return notice_date;
	}
	public void setNotice_Date(String date) {
		this.notice_date = date;
	}
	
	
}
