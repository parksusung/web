package website;

public class signInBean {

   private String id;
   private String passwd;
   private String nick;
   private String tel;
   private String admin;
   
   public String getAdmin() {
	      return admin;
	   }
	   public void setAdmin(String admin){
	      this.admin = admin;
	   }
	   
   public String getTel() {
      return tel;
   }
   public void setTel(String tel){
      this.tel = tel;
   }
   public String getId() {
      return id;
   }
   public void setId(String id) {
      this.id = id;
   }
   
   public String getPasswd() {
      return passwd;
   }
   public void setPasswd(String passwd) {
      this.passwd = passwd;
   }
   public String getNick() {
      
      return nick;
   }
   public void setNick(String nick) {
      this.nick = nick;
   }
   
   
}