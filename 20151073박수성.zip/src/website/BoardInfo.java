package website;

import java.sql.*;
import java.util.ArrayList;

public class BoardInfo {
	Connection conn = null;
	PreparedStatement pstmt = null;

	/* MySQL 연결정보 */
	String jdbc_driver = "com.mysql.jdbc.Driver";
	String jdbc_url = "jdbc:mysql://localhost/jspdb?characterEncoding=UTF-8&serverTimezone=UTC";

	// DB연결 메서드
	void connect() {
		try {
			Class.forName(jdbc_driver);

			conn = DriverManager.getConnection(jdbc_url, "jspbook", "1234");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	void disconnect() {
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// 수정된 내용 갱신을 위한 메서드
	public boolean updateDB(int board_id, String title, String article, String date) {
		connect();

		String sql = "update board_info set title=?,article=?,date=? where board_id=?";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, title);
			pstmt.setString(2, article);
			pstmt.setString(3, date);
			pstmt.setInt(4, board_id);
	
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	// 특정 주소록 게시글 삭제 메서드
	public boolean deleteDB(int board_id) {
		connect();

		String sql = "delete from board_info where board_id=?";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, board_id);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	// 신규  메시지 추가 메서드
	public boolean insertDB(BoardBean boardbean) {
		connect();
		// sql 문자열 , gb_id 는 자동 등록 되므로 입력하지 않는다.

		String sql = "insert into board_info(title,nick,article,date,count) values(?,?,?,?,?)";

		try {
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, boardbean.getTitle());
			pstmt.setString(2 ,boardbean.getNick());
			pstmt.setString(3, boardbean.getArticle());
			pstmt.setString(4, boardbean.getDate());
			pstmt.setInt(5, boardbean.getCount());
		
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	// 특정 게시글 가져오는 메서드
	//title을 클릭하면 board_id가 선택되어야함
	public BoardBean getDB(int board_id, boolean add) {
		connect();

		String sql = "select * from board_info where board_id=?";
		BoardBean boardbean = new BoardBean();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, board_id);
			ResultSet rs = pstmt.executeQuery();

			// 데이터가 하나만 있으므로 rs.next()를 한번만 실행 한다.
			rs.next();

			boardbean.setBoard_id(rs.getInt("board_id"));
			boardbean.setTitle(rs.getString("title"));
			boardbean.setNick(rs.getString("nick"));
			boardbean.setArticle(rs.getString("article"));
			boardbean.setDate(rs.getString("date"));
			boardbean.setCount(rs.getInt("count"));
			
			//boolean값 add를 받고 모드가 null이면 조회수(count)를 올린다
			if(add) {
				sql = "update board_info set count=? where board_id=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(2, board_id);
				pstmt.setInt(1,boardbean.getCount()+1);
				pstmt.executeUpdate();				
			}
			
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return boardbean;
	}


	// 전체 주소록 목록을 가져오는 메서드
	public ArrayList<BoardBean> getDBList() {
		connect();
		ArrayList<BoardBean> datas = new ArrayList<BoardBean>();

		String sql = "select * from board_info order by board_id desc";
		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				BoardBean boardbean = new BoardBean();
				boardbean.setBoard_id(rs.getInt("board_id"));
				boardbean.setTitle(rs.getString("title"));
				boardbean.setNick(rs.getString("nick"));
				boardbean.setArticle(rs.getString("article"));
				boardbean.setDate(rs.getString("date"));
				boardbean.setCount(rs.getInt("count"));
				
				datas.add(boardbean);
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return datas;
	}
	
	
}
