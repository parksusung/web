package website;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class userInfo {
   Connection conn = null;
   PreparedStatement pstmt = null;

    String jdbc_driver = "com.mysql.jdbc.Driver";
      String jdbc_url = "jdbc:mysql://localhost/jspdb?characterEncoding=UTF-8&serverTimezone=UTC";
     
   void connect() {
      try {
         Class.forName(jdbc_driver);

         conn = DriverManager.getConnection(jdbc_url, "jspbook", "1234");
      } catch (Exception e) {
         e.printStackTrace();
      }
   }

   void disconnect() {
      if (pstmt != null) {
         try {
            pstmt.close();
         } catch (SQLException e) {
            e.printStackTrace();
         }
      }
      if (conn != null) {
         try {
            conn.close();
         } catch (SQLException e) {
            e.printStackTrace();
         }
      }
   }

   // DB에 새로운값을 삽입할때 사용한다.
   public boolean insertDB(signInBean SignInbean) {
      connect();

      String sql = "insert into user_info(id,passwd,nick,tel,admin) values(?,?,?,?,?)";

      try {
         pstmt = conn.prepareStatement(sql);
         pstmt.setString(1, SignInbean.getId());
         pstmt.setString(2, SignInbean.getPasswd());
         pstmt.setString(3, SignInbean.getNick());
         pstmt.setString(4, SignInbean.getTel());
         pstmt.setString(5, "0");

         pstmt.executeUpdate();
      } catch (SQLException e) {
         e.printStackTrace();
         return false;
      } finally {
         disconnect();
      }
      return true;
   }

   //받은 id값이 존재하는지 확인한다(중복체크)
   public boolean checkId(String id) {
      connect();
      String sql = "select id from user_info where id=?";
      try {
         pstmt = conn.prepareStatement(sql);
         pstmt.setString(1, id);
         ResultSet rs = pstmt.executeQuery();
         if (rs.next()) {//테이블에 id가 존재할때
            rs.close();
            disconnect();
            return false;

         } else{
            //join.html을 호출한다.
            rs.close();
            disconnect();
            return true;
         }
      } catch (SQLException e) {
         e.printStackTrace();
      } finally {
         disconnect();
      }
      return false;

   }

   // 로그인할때 존재하는 id인지 체크한 후 닉네임 값을 넘겨준다.
   public String checkUser(String id, String passwd) {
      connect();

      String sql = "select * from user_info where id=?";
      signInBean signInBean = new signInBean();

      try {
         pstmt = conn.prepareStatement(sql);
         pstmt.setString(1, id);
         ResultSet rs = pstmt.executeQuery();

         while (rs.next()) {
            if (id.equals(rs.getString("id"))) {
               if (passwd.equals(rs.getString("passwd"))) {//id와 passwd가 일치할때
                  String nick=rs.getString("nick");
                
                  rs.close();
                  disconnect();
                  
                  return nick;
               }
            }return null;
         }
         rs.close();
      } catch (SQLException e) {
         e.printStackTrace();
      } finally {
         disconnect();
      }

      return null;
   }
   
   public String getAdmin(String id, String passwd) {
	      connect();

	      String sql = "select * from user_info where id=?";
	      signInBean signInBean = new signInBean();

	      try {
	         pstmt = conn.prepareStatement(sql);
	         pstmt.setString(1, id);
	         ResultSet rs = pstmt.executeQuery();

	         while (rs.next()) {
	            if (id.equals(rs.getString("id"))) {
	               if (passwd.equals(rs.getString("passwd"))) {//id와 passwd가 일치할때
	              
	                  String admin=rs.getString("admin");
	                  rs.close();
	                  disconnect();
	                  
	                  return admin;
	               }
	            }return null;
	         }
	         rs.close();
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         disconnect();
	      }

	      return null;
	   }

}